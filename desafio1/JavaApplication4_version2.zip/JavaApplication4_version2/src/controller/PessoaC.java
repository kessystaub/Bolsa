/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import conexao.ConectaBD;
import dao.PessoaDAO;
import java.sql.Connection;
import java.sql.SQLException;
import model.Administrador;
import model.Usuario;
import static view.Console.imprime;

/**
 *
 * @author Pichau
 */
public class PessoaC {
        public static void iniciar() throws SQLException{
        Connection connection = ConectaBD.createConnectionMySQL();
        if(connection != null){
            System.out.println("Conexão realizada com sucesso");
            connection.close();
        }
        
        PessoaDAO pessoaDAO = new PessoaDAO();
        
        //Usuario usuario = new Usuario("roberto","9923-8421","12/12/2000","rua 213","senha123");
        //pessoaDAO.saveUser(usuario);
        
        //Administrador adm = new Administrador("rosangela","9933-8322","11/11/2010","rua 313","senha");
        //pessoaDAO.saveAdm(adm);
        
        //Usuario usuario2 = new Usuario("ana","9990-1234","12/12/2020","rua 234");
        //usuarioDAO.updateUser(usuario2,1);
        
        //usuarioDAO.delete(1);
        //usuarioDAO.ativar(1);
        
        
        //pessoaDAO.senha();
        //imprime(pessoaDAO);
    }
}
