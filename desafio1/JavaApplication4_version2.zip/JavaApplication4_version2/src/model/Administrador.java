/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Pichau
 */
public class Administrador extends Pessoa{
    
    private int adm = 1;

    public int getAdm() {
        return adm;
    }

    public void setAdm(int adm) {
        this.adm = adm;
    }
    
    public Administrador(){
    }
    
    public Administrador(String nome, String telefone, String datanascimento, String endereco, String senha){
        super(nome,telefone,datanascimento,endereco,senha);
    }
}
