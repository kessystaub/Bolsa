/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import conexao.ConectaBD;
import dao.PessoaDAO;
import java.sql.Connection;
import java.sql.SQLException;
import model.Usuario;
import static view.Console.imprime;

/**
 *
 * @author Pichau
 */
public class PessoaC {
        public static void iniciar() throws SQLException{
        Connection connection = ConectaBD.createConnectionMySQL();
        if(connection != null){
            System.out.println("Conexão realizada com sucesso");
            connection.close();
        }
        
        PessoaDAO usuarioDAO = new PessoaDAO();
        
        Usuario usuario = new Usuario("fabiana","9923-8421","12/12/2000","rua 213");
        usuarioDAO.save(usuario);
      
        //Jogo jogo = new Jogo(2011, "Dota 2", "moba", "Original");
        //jogoDAO.save(jogo);

        //Jogo jogo = new Jogo(2009, "LOL", "moba", "Jogo");
        //jogoDAO.update(jogo,1); //envia o jogo e o id que deseja fazer o update

        //jogoDAO.delete(1);
        //jogoDAO.ativar(1);
        
        
        imprime(usuarioDAO);
        
    }
}
