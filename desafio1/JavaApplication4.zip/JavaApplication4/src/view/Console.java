/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

import dao.PessoaDAO;
import java.util.ArrayList;
import java.util.List;
import model.Administrador;
import model.Usuario;

/**
 *
 * @author Pichau
 */
public class Console {
    public static void imprime(PessoaDAO pessoaDAO){
        List<Usuario> usuarios = new ArrayList<Usuario>();
        usuarios = pessoaDAO.getUser();
        
        List<Administrador> adms = new ArrayList<Administrador>();
        adms = pessoaDAO.getAdm();
        
        for(Usuario usuario: usuarios){
            System.out.print("  ID: "+ usuario.getId());
            System.out.print("  Nome: "+usuario.getNome());
            System.out.print("  Telefone: "+usuario.getTelefone());
            System.out.print("  Data de Nascimento: "+usuario.getDatanascimento());
            System.out.println("    Endereco: "+usuario.getEndereco());
        }
        
        for(Administrador adm: adms){
            System.out.print("  ID: "+ adm.getId());
            System.out.print("  Nome: "+adm.getNome());
            System.out.print("  Telefone: "+adm.getTelefone());
            System.out.print("  Data de Nascimento: "+adm.getDatanascimento());
            System.out.println("    Endereco: "+adm.getEndereco());
        }
        
    }
}
