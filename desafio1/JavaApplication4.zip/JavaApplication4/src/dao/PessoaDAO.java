/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Usuario;

/**
 *
 * @author Pichau
 */
public class PessoaDAO {
        public void save(Usuario usuario) {
        String QUERY = "INSERT INTO pessoa (nome, telefone, dataNascimento, endereco)"
                + " VALUES (?, ?, ?, ?)";
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = conexao.ConectaBD.createConnectionMySQL();
            preparedStatement = (PreparedStatement) connection.prepareStatement(QUERY);
            preparedStatement.setString(1, usuario.getNome());
            preparedStatement.setString(2, usuario.getTelefone());
            preparedStatement.setString(3, usuario.getDatanascimento());
            preparedStatement.setString(4, usuario.getEndereco());

            preparedStatement.execute();
            System.out.println("Salvo com sucesso");

        } catch (SQLException ex) {
            Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
