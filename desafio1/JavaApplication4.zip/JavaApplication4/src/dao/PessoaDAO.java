/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Administrador;
import model.Pessoa;
import model.Usuario;

/**
 *
 * @author Pichau
 */
public class PessoaDAO {
 /*
    public void adicionaCriptografado(Usuario usuario) {

    // Gera um sal aleatório
    String salGerado = BCrypt.gensalt();
    System.out.println("O sal gerado foi $" + salGerado + "$");

    // Gera a senha hasheada utilizando o sal gerado
    String senhaHasheada = BCrypt.hashpw(usuario.getSenha(), salGerado);

    //Atualiza a senha do usuário
    usuario.setSenha(senhaHasheada);

    //Salva no banco
    adicionaNoBanco(usuario);

}
  */  
    
    
//ALTER TABLE `pessoa` ADD `senha` VARCHAR(11) NOT NULL AFTER `nome`; 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    public void saveUser(Usuario usuario) {
        String QUERY = "INSERT INTO pessoa (nome, telefone, dataNascimento, endereco, senha)"
                + " VALUES (?, ?, ?, ?, ?)";
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = conexao.ConectaBD.createConnectionMySQL();
            preparedStatement = (PreparedStatement) connection.prepareStatement(QUERY);
            preparedStatement.setString(1, usuario.getNome());
            preparedStatement.setString(2, usuario.getTelefone());
            preparedStatement.setString(3, usuario.getDatanascimento());
            preparedStatement.setString(4, usuario.getEndereco());
            preparedStatement.setString(5, usuario.getSenha());

            preparedStatement.execute();
            System.out.println("Usuario Salvo com sucesso");

        } catch (SQLException ex) {
            Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }     
        
    public void updateUser(Usuario usuario, int id){
            
        String QUERY = "UPDATE pessoa SET nome = ?, telefone = ?, dataNascimento = ?, endereco = ?, senha = ? WHERE pessoa.id = ?";
        Connection connection = null;
        PreparedStatement preparedStatement = null;
            
        try {
            connection = conexao.ConectaBD.createConnectionMySQL();
            preparedStatement = (PreparedStatement) connection.prepareStatement(QUERY);
            preparedStatement.setString(1, usuario.getNome());
            preparedStatement.setString(2, usuario.getTelefone());
            preparedStatement.setString(3, usuario.getDatanascimento());
            preparedStatement.setString(4, usuario.getEndereco());
            preparedStatement.setString(5, usuario.getSenha());
            preparedStatement.setInt(6, id);

            preparedStatement.execute();
            System.out.println("Usuario Editado com sucesso");

        } catch (SQLException ex) {
            Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public List<Usuario> getUser() {
        List<Usuario> usuarios = new ArrayList<Usuario>();
        String QUERY = "SELECT * FROM pessoa WHERE ativo != 0 AND adm = 0";
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;       

        try {
            connection = conexao.ConectaBD.createConnectionMySQL();
            preparedStatement = (PreparedStatement) connection.prepareStatement(QUERY);
            
            resultSet = preparedStatement.executeQuery(QUERY);
            
            while (resultSet.next()) {
                Usuario usuario = new Usuario();
                
                usuario.setId(resultSet.getInt("id"));
                usuario.setNome(resultSet.getString("nome"));
                usuario.setTelefone(resultSet.getString("telefone"));
                usuario.setDatanascimento(resultSet.getString("dataNascimento"));
                usuario.setEndereco(resultSet.getString("endereco"));
                
                usuarios.add(usuario);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return usuarios;
    }
    
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    public void saveAdm(Administrador administrador) {
        String QUERY = "INSERT INTO pessoa (nome, telefone, dataNascimento, endereco, adm, senha)"
                + " VALUES (?, ?, ?, ?, ?, ?)";
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            connection = conexao.ConectaBD.createConnectionMySQL();
            preparedStatement = (PreparedStatement) connection.prepareStatement(QUERY);
            preparedStatement.setString(1, administrador.getNome());
            preparedStatement.setString(2, administrador.getTelefone());
            preparedStatement.setString(3, administrador.getDatanascimento());
            preparedStatement.setString(4, administrador.getEndereco());
            preparedStatement.setInt(5, administrador.getAdm());
            preparedStatement.setString(6, administrador.getSenha());

            preparedStatement.execute();
            System.out.println("Administrador Salvo com sucesso");

        } catch (SQLException ex) {
            Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }     
        
    public void updateAdm(Administrador administrador, int id){
        
        String QUERY = "UPDATE pessoa SET nome = ?, telefone = ?, dataNascimento = ?, endereco = ?, senha = ? WHERE pessoa.id = ?";
        Connection connection = null;
        PreparedStatement preparedStatement = null;
            
        try {
            connection = conexao.ConectaBD.createConnectionMySQL();
            preparedStatement = (PreparedStatement) connection.prepareStatement(QUERY);
            preparedStatement.setString(1, administrador.getNome());
            preparedStatement.setString(2, administrador.getTelefone());
            preparedStatement.setString(3, administrador.getDatanascimento());
            preparedStatement.setString(4, administrador.getEndereco());
            preparedStatement.setString(5, administrador.getSenha());
            preparedStatement.setInt(6, id);

            preparedStatement.execute();
            System.out.println("Administrador Editado com sucesso");

        } catch (SQLException ex) {
            Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public List<Administrador> getAdm() {
        List<Administrador> administradores = new ArrayList<Administrador>();
        String QUERY = "SELECT * FROM pessoa WHERE ativo != 0 AND adm = 1";
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;       

        try {
            connection = conexao.ConectaBD.createConnectionMySQL();
            preparedStatement = (PreparedStatement) connection.prepareStatement(QUERY);
            
            resultSet = preparedStatement.executeQuery(QUERY);
            
            while (resultSet.next()) {
                Administrador administrador = new Administrador();
                
                administrador.setId(resultSet.getInt("id"));
                administrador.setNome(resultSet.getString("nome"));
                administrador.setTelefone(resultSet.getString("telefone"));
                administrador.setDatanascimento(resultSet.getString("dataNascimento"));
                administrador.setEndereco(resultSet.getString("endereco"));
                
                administradores.add(administrador);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return administradores;
    }
    
    
    
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        
    public void delete(int id){
        String QUERY = "UPDATE pessoa SET ativo = ? WHERE pessoa.id = ?";
        Connection connection = null;
        PreparedStatement preparedStatement = null;
            
        try {
            connection = conexao.ConectaBD.createConnectionMySQL();
            preparedStatement = (PreparedStatement) connection.prepareStatement(QUERY);
            preparedStatement.setString(1, "0");
            preparedStatement.setInt(2, id);

            preparedStatement.execute();
            System.out.println("Deletado/Desativado com sucesso");

        } catch (SQLException ex) {
            Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    
    public void ativar(int id){
        String QUERY = "UPDATE pessoa SET ativo = ? WHERE pessoa.id = ?";
        Connection connection = null;
        PreparedStatement preparedStatement = null;
            
        try {
            connection = conexao.ConectaBD.createConnectionMySQL();
            preparedStatement = (PreparedStatement) connection.prepareStatement(QUERY);
            preparedStatement.setString(1, "1");
            preparedStatement.setInt(2, id);

            preparedStatement.execute();
            System.out.println("Ativado com sucesso");

        } catch (SQLException ex) {
            Logger.getLogger(PessoaDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
